<?= $this->extend('layout/user_template'); ?>
<?= $this->section('content'); ?>

<?= $this->endSection('content'); ?>